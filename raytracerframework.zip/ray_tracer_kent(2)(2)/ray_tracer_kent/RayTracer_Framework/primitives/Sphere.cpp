#include "sphere.h"
#include "../Imageio/Imageio.h"
#include <math.h>

Intersect_Cond	Sphere::intersection_check(const M3DVector3f start, const M3DVector3f dir, float & distance, M3DVector3f intersection_p)
{
	M3DVector3f ray_to_center;
	m3dSubtractVectors3(ray_to_center,_pos,start);
	float ray_center_length = m3dDotProduct(ray_to_center, ray_to_center); 

	float closest_point = m3dDotProduct( ray_to_center, dir);
	if (closest_point < 0) 
	{
		return _k_miss;
	}

	float halfCord2 = (_rad * _rad) - (ray_center_length - (closest_point * closest_point));   
	if(halfCord2 < 0) 
	{
		return _k_miss;
	}

	Intersect_Cond type;
	M3DVector3f tmp;
	m3dSubtractVectors3(tmp,start,_pos);
	float length = m3dDotProduct(tmp,tmp);
	if (length < _rad2)
	{
		type = _k_inside;
		distance = closest_point + sqrt(halfCord2);
	}else
	{
		type = _k_hit;
		distance = closest_point - sqrt(halfCord2);
	}

	M3DVector3f tmp_v;
	m3dCopyVector3(tmp_v, dir);
	m3dScaleVector3(tmp_v,distance);
	m3dAddVectors3(intersection_p,start,tmp_v);

	return type;
}

void	Sphere::shade(M3DVector3f view,M3DVector3f intersect_p,const Light & sp_light, M3DVector3f am_light, M3DVector3f color, bool shadow)
{
//Make the view direction pointing to the viewer
	m3dScaleVector3(view, -1);
	m3dNormalizeVector(view);

	//For Sphere shading, compute normal for each point on the sphere
	M3DVector3f normal;
	m3dSubtractVectors3(normal, intersect_p, _pos);
	m3dNormalizeVector(normal);

	//For Wall shading, get normal for the wall face from one of its triangles 
	//M3DVector3f normal;
	//_tr1.normal(normal);
	//m3dNormalizeVector(normal);


	M3DVector3f light_dir, light_pos, light_color;

	//Get the location and color of the light source
	sp_light.get_light(light_pos, light_color);

	//Compute the vector pointing to the light source
	m3dSubtractVectors3(light_dir, light_pos, intersect_p);
	m3dNormalizeVector(light_dir);

	//Compute diffusion with dot product
	float diffuse_coef = m3dDotProduct(light_dir, normal);

	//Compute perfect specular direction r
	float sp_coeff;
	M3DVector3f h, r;
	//Use Blinn model to compute r:
	//m3dAddVectors3(h, light_dir, view);
	//m3dNormalizeVector(h);
	////Compute specular dot product
	//sp_coeff = m3dDotProduct(normal, h);

	//Use original Phong model to compute r:
	M3DVector3f  tmp;
	m3dCopyVector3(tmp, normal);
	m3dScaleVector3(tmp, (2 * diffuse_coef));
	m3dSubtractVectors3(r, tmp, light_dir);
	//Compute specular dot product
	sp_coeff = m3dDotProduct(view, r);

	//Compute specular with shineness coefficient
	sp_coeff = pow(sp_coeff, 11);


	//Generate color with Phong model
	for (int i = 0; i < 3; i++)
	{
		color[i] = _kd * diffuse_coef * _color[i] + _ks * sp_coeff * light_color[i] + _ka * am_light[i];

		//remore larger and negative numerics
		if (color[i] > 1)
			color[i] = 1;
		if (color[i] < 0)
			color[i] = 0;
	}
}
