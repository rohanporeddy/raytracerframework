#pragma once
#include "Basic_Primitive.h"
#include "Triangle.h"
#include "../common/image_volume.h"
#include <string>
#include <vector>

class Mesh:public Basic_Primitive
{
public:
	Mesh(M3DVector3f color)
		:Basic_Primitive(_k_mesh)
		,_texture(NULL)
	{
		m3dCopyVector3(_color,color);
		_kd = 1.0;
		_ka = 0.3;
		_ks = 1.0;
		_ks2 = _ks;
		_kt	 = 0.0;	
		_ws  = 0.0;
		_wt  = 0.0;	

		intersected_triangle = NULL;
	}

public:
	~Mesh(void) 
	{
		if(_texture != NULL)  
		{ 
			delete [] _texture->data; 
			delete _texture;
		} 	
	}

public:
	Intersect_Cond	intersection_check(const M3DVector3f start, const M3DVector3f dir, float & distance, M3DVector3f intersection_p);
	void	shade(M3DVector3f view,M3DVector3f intersect_p,const Light & sp_light, M3DVector3f am_light, M3DVector3f color, bool shadow);
	//void	get_reflect_direction(M3DVector3f dir);
	void	get_reflect_direct(const M3DVector3f direct,const M3DVector3f intersect_p,M3DVector3f reflect_direct);
	void	get_properties(float & ks,float & kt, float & ws, float & wt) const { ks = _ks2; kt = _kt; ws = _ws; wt = _wt;	}
	void	set_properties(float ks, float  kt, float  ws, float  wt) { _ks2 = _ks = ks; _kt = kt; _ws = ws; _wt = wt;	}
public:
	void load_obj(std::string file_name);
	void transform(M3DMatrix44f matrix);
	void load_texture(std::string file_name) ;
private:
	inline void	get_color(M3DVector3f pos, M3DVector3f color) { if(_texture == NULL) m3dCopyVector3(color, _color); else texture_color(pos, color); }
	void	texture_color(M3DVector3f pos, M3DVector3f color);
	void	get_texel(float x, float y, M3DVector3f color);
private:
	M3DVector3f _color;
	float		_kd;
	float		_ks;
	float		_ka;

	float		_ws;
	float		_wt;
	float		_kt;
	float		_ks2;

private:
	std::vector<Triangle> triangles;
	Triangle * intersected_triangle;
	Image *	_texture;
};
