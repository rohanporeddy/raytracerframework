#include "Mesh.h"
#include <math.h>
#include <fstream>
#include <vector>
#include "../Imageio/Imageio.h"

Intersect_Cond Mesh::intersection_check(const M3DVector3f start, const M3DVector3f dir, float &distance, M3DVector3f intersection_p)
{
	distance = 1e10;
	intersected_triangle = NULL;
	for (std::vector<Triangle>::iterator it = triangles.begin(); it != triangles.end(); ++it)
	{
		float d = 0;
		Triangle & triangle = *it;

		if (it->intersection_check(start, dir, d, intersection_p) == _k_hit && d < distance)
		{
			distance = d;
			intersected_triangle = &triangle;
		}
	}

	return intersected_triangle ? _k_hit : _k_miss;
}

void	Mesh::shade(M3DVector3f view, M3DVector3f intersect_p,const Light & sp_light, M3DVector3f am_light, M3DVector3f color,bool shadow)
{
	M3DVector3f lpos, lcolor;
	sp_light.get_light(lpos, lcolor);
	M3DVector3f n;
	intersected_triangle->normal(n);
	M3DVector3f ldir;
	m3dSubtractVectors3(ldir, lpos, intersect_p);
	m3dNormalizeVector(ldir);
	float d = m3dDotProduct(ldir, n);

	M3DVector3f rdir;
	m3dCopyVector3(rdir, n);
	m3dScaleVector3(rdir, 2 * d);
	m3dSubtractVectors3(rdir, ldir, rdir);

	float s = m3dDotProduct(rdir, view);
	for (int i = 0; i < 3; i++)
	{
		color[i] = _ka * _color[i] * am_light[i];
		if (d > 0)
			color[i] += _kd * _color[i] * lcolor[i] * d;
		if (s > 0)
			color[i] += _ks * lcolor[i] * pow(s, 100);
	}
}

void	Mesh::get_reflect_direct(const M3DVector3f direct0,const M3DVector3f intersect_p, M3DVector3f reflect_direct)
{
	
}

void Mesh::load_obj(std::string file_name)
{
	std::ifstream file(file_name.c_str());
	if (!file)
	{
		printf("Can't open input file %s. Exiting.\n", file_name.c_str());
		exit(1);
	}
	struct Vertex { float x, y, z; };
	std::vector<Vertex> vertices;

	std::string line;
	while (getline(file, line))
	{
		Vertex vertex;
		if (sscanf(line.c_str(), "v %f %f %f", &vertex.x, &vertex.y, &vertex.z) == 3)
		{
			vertices.push_back(vertex);
		}

		int i0, i1, i2;
		if (sscanf(line.c_str(), "f %d %d %d", &i0, &i1, &i2) == 3)
		{
			i0--;
			i1--;
			i2--;
			M3DVector3f v0, v1, v2;
			m3dLoadVector3(v0, vertices[i0].x, vertices[i0].y, vertices[i0].z);
			m3dLoadVector3(v1, vertices[i1].x, vertices[i1].y, vertices[i1].z);
			m3dLoadVector3(v2, vertices[i2].x, vertices[i2].y, vertices[i2].z);
			triangles.push_back(Triangle(v0, v1, v2));
		}
	}
}

void Mesh::transform(M3DMatrix44f matrix)
{

	for (std::vector<Triangle>::iterator it = triangles.begin(); it != triangles.end(); ++it)
	{

		M3DVector3f v0, v1, v2;
		m3dTransformVector3(v0, it->_v0, matrix);
		m3dTransformVector3(v1, it->_v1, matrix);
		m3dTransformVector3(v2, it->_v2, matrix);
		m3dCopyVector3(it->_v0, v0);
		m3dCopyVector3(it->_v1, v1);
		m3dCopyVector3(it->_v2, v2);
	}
}

void Mesh::load_texture(std::string file_name)
{
	
}

void Mesh::texture_color(M3DVector3f pos, M3DVector3f color)
{
}

void	Mesh::get_texel(float x, float y, M3DVector3f color)
{
	return;
}
